{{- define "continuous-ai.name" -}}continuous-ai{{- end }}
{{- define "continuous-ai.fullname" -}}{{ .Release.Name }}{{- end }}
{{- define "continuous-ai.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}{{ default (include "continuous-ai.fullname" .) .Values.serviceAccount.name }}{{ else }}{{ .Values.serviceAccount.name }}{{ end -}}
{{- end }}

