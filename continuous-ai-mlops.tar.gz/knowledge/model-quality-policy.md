# Model quality policy

Production promotion requires a representative evaluation dataset, recorded dataset version,
reproducible MLflow run, passing operational checks, and an approved deployment record.

Never claim accuracy without joined ground-truth labels. Drift and confidence changes are warning
signals, not proof that predictions are incorrect.

A challenger must not regress the primary quality metric by more than 1%, must satisfy the defined
minimum safety metric, and must remain below the service latency and error-rate objectives.

