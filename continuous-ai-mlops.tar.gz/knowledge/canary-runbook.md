# Canary deployment runbook

Begin at 5% traffic. Observe at least one complete evaluation window and enough labeled outcomes
to satisfy the model policy. Increase to 20%, 50%, and 100% only when deterministic gates pass.

Immediately return traffic to the champion for severe error-rate, latency, schema, or safety gate
failures. Quality rollback requires enough ground truth to avoid reacting to random noise.

