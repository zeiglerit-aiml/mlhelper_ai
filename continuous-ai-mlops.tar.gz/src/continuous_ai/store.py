import json
import sqlite3
from collections.abc import Iterator
from contextlib import contextmanager
from pathlib import Path

from continuous_ai.schemas import GroundTruthEvent, PipelineEvent, PredictionEvent


class EventStore:
    """Small durable MVP store. Replace with Postgres for multi-replica production."""

    def __init__(self, database_url: str):
        if not database_url.startswith("sqlite:///"):
            raise ValueError("MVP EventStore currently supports sqlite:/// URLs")
        self.path = Path(database_url.removeprefix("sqlite:///"))
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.initialize()

    @contextmanager
    def connection(self) -> Iterator[sqlite3.Connection]:
        connection = sqlite3.connect(self.path)
        connection.row_factory = sqlite3.Row
        try:
            yield connection
            connection.commit()
        finally:
            connection.close()

    def initialize(self) -> None:
        with self.connection() as connection:
            connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS pipeline_events (
                    event_id TEXT PRIMARY KEY,
                    occurred_at TEXT NOT NULL,
                    model_name TEXT NOT NULL,
                    payload TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS predictions (
                    prediction_id TEXT PRIMARY KEY,
                    occurred_at TEXT NOT NULL,
                    model_name TEXT NOT NULL,
                    model_version TEXT NOT NULL,
                    prediction TEXT NOT NULL,
                    probability REAL,
                    features TEXT NOT NULL,
                    latency_ms REAL,
                    trace_id TEXT
                );
                CREATE TABLE IF NOT EXISTS ground_truth (
                    prediction_id TEXT PRIMARY KEY,
                    actual TEXT NOT NULL,
                    observed_at TEXT NOT NULL,
                    FOREIGN KEY(prediction_id) REFERENCES predictions(prediction_id)
                );
                """
            )

    def add_pipeline_event(self, event: PipelineEvent) -> None:
        with self.connection() as connection:
            connection.execute(
                "INSERT OR REPLACE INTO pipeline_events VALUES (?, ?, ?, ?)",
                (str(event.event_id), event.occurred_at.isoformat(), event.model_name,
                 event.model_dump_json()),
            )

    def add_prediction(self, event: PredictionEvent) -> None:
        with self.connection() as connection:
            connection.execute(
                """INSERT OR REPLACE INTO predictions
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    str(event.prediction_id), event.occurred_at.isoformat(), event.model_name,
                    event.model_version, json.dumps(event.prediction), event.probability,
                    json.dumps(event.features), event.latency_ms, event.trace_id,
                ),
            )

    def add_ground_truth(self, event: GroundTruthEvent) -> None:
        with self.connection() as connection:
            connection.execute(
                "INSERT OR REPLACE INTO ground_truth VALUES (?, ?, ?)",
                (str(event.prediction_id), json.dumps(event.actual), event.observed_at.isoformat()),
            )

    def labeled_predictions(self, model_name: str, model_version: str | None = None) -> list[dict]:
        query = """
            SELECT p.*, g.actual, g.observed_at
            FROM predictions p JOIN ground_truth g USING(prediction_id)
            WHERE p.model_name = ?
        """
        parameters: list[str] = [model_name]
        if model_version:
            query += " AND p.model_version = ?"
            parameters.append(model_version)
        with self.connection() as connection:
            rows = connection.execute(query, parameters).fetchall()
        return [
            {
                **dict(row),
                "prediction": json.loads(row["prediction"]),
                "actual": json.loads(row["actual"]),
                "features": json.loads(row["features"]),
            }
            for row in rows
        ]
