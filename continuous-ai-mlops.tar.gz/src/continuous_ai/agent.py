import json
from collections.abc import Callable
from typing import Any

from openai import OpenAI


class ContinuousAIAgent:
    def __init__(self, api_key: str, model: str, tools: dict[str, Callable[..., Any]]):
        self.client = OpenAI(api_key=api_key)
        self.model = model
        self.tools = tools

    @staticmethod
    def tool_schemas() -> list[dict[str, Any]]:
        return [
            {
                "type": "function",
                "name": "search_knowledge",
                "description": "Search model cards, policies, and runbooks before making recommendations.",
                "parameters": {
                    "type": "object",
                    "properties": {"query": {"type": "string"}},
                    "required": ["query"],
                    "additionalProperties": False,
                },
                "strict": True,
            },
            {
                "type": "function",
                "name": "evaluate_model",
                "description": "Calculate quality metrics from stored predictions joined to ground truth.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "model_name": {"type": "string"},
                        "model_version": {"type": ["string", "null"]},
                        "task_type": {"type": "string", "enum": ["classification", "regression"]},
                    },
                    "required": ["model_name", "model_version", "task_type"],
                    "additionalProperties": False,
                },
                "strict": True,
            },
            {
                "type": "function",
                "name": "get_mlflow_model",
                "description": "Get an MLflow registered model version by alias.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "model_name": {"type": "string"},
                        "alias": {"type": "string"},
                    },
                    "required": ["model_name", "alias"],
                    "additionalProperties": False,
                },
                "strict": True,
            },
            {
                "type": "function",
                "name": "get_model_telemetry",
                "description": "Get request rate, error rate, and latency from Prometheus.",
                "parameters": {
                    "type": "object",
                    "properties": {"model_name": {"type": "string"}},
                    "required": ["model_name"],
                    "additionalProperties": False,
                },
                "strict": True,
            },
            {
                "type": "function",
                "name": "get_model_health",
                "description": "Call a configured model endpoint health route.",
                "parameters": {
                    "type": "object",
                    "properties": {"model_name": {"type": "string"}},
                    "required": ["model_name"],
                    "additionalProperties": False,
                },
                "strict": True,
            },
            {
                "type": "function",
                "name": "get_kubernetes_deployments",
                "description": "Inspect model deployment readiness in the configured namespace.",
                "parameters": {
                    "type": "object",
                    "properties": {},
                    "required": [],
                    "additionalProperties": False,
                },
                "strict": True,
            },
        ]

    def ask(self, message: str) -> str:
        conversation: list[Any] = [{"role": "user", "content": message}]
        for _ in range(8):
            response = self.client.responses.create(
                model=self.model,
                instructions=(
                    "You are a Continuous AI MLOps investigator. Use tools to gather evidence. "
                    "Never invent metrics, deployments, model versions, or completed actions. "
                    "Distinguish measured facts from hypotheses. State when ground truth is missing. "
                    "You have read-only tools; recommend changes but never claim they were executed."
                ),
                input=conversation,
                tools=self.tool_schemas(),
            )
            conversation.extend(item.model_dump() for item in response.output)
            calls = [item for item in response.output if item.type == "function_call"]
            if not calls:
                return response.output_text
            for call in calls:
                try:
                    arguments = json.loads(call.arguments)
                    output = self.tools[call.name](**arguments)
                except Exception as error:  # noqa: BLE001 - isolate connector failures from the loop.
                    output = {"error": type(error).__name__, "message": str(error)}
                conversation.append(
                    {
                        "type": "function_call_output",
                        "call_id": call.call_id,
                        "output": json.dumps(output, default=str),
                    }
                )
        return "The investigation reached its maximum tool-call limit."
