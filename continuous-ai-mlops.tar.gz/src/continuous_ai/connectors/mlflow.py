from typing import Any

from mlflow import MlflowClient, set_tracking_uri


class MLflowConnector:
    def __init__(self, tracking_uri: str | None):
        self.enabled = bool(tracking_uri)
        if tracking_uri:
            set_tracking_uri(tracking_uri)
            self.client = MlflowClient(tracking_uri=tracking_uri)

    def model_by_alias(self, model_name: str, alias: str = "champion") -> dict[str, Any]:
        if not self.enabled:
            return {"error": "MLFLOW_TRACKING_URI is not configured"}
        version = self.client.get_model_version_by_alias(model_name, alias)
        return {
            "name": version.name,
            "version": version.version,
            "run_id": version.run_id,
            "status": str(version.status),
            "source": version.source,
            "aliases": list(version.aliases or []),
            "tags": dict(version.tags or {}),
        }

    def run(self, run_id: str) -> dict[str, Any]:
        if not self.enabled:
            return {"error": "MLFLOW_TRACKING_URI is not configured"}
        run = self.client.get_run(run_id)
        return {
            "run_id": run.info.run_id,
            "status": run.info.status,
            "artifact_uri": run.info.artifact_uri,
            "metrics": dict(run.data.metrics),
            "parameters": dict(run.data.params),
            "tags": dict(run.data.tags),
        }

