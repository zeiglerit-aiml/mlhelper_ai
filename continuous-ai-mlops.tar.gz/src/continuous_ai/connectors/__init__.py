"""External system adapters used as bounded agent tools."""

