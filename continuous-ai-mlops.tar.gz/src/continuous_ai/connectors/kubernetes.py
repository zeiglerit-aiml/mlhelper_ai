from typing import Any

from kubernetes import client, config


class KubernetesConnector:
    def __init__(self, namespace: str, enabled: bool):
        self.namespace = namespace
        self.enabled = enabled
        self._loaded = False

    def _load(self) -> None:
        if not self.enabled:
            return
        if not self._loaded:
            try:
                config.load_incluster_config()
            except config.ConfigException:
                config.load_kube_config()
            self._loaded = True

    def deployments(self) -> dict[str, Any]:
        if not self.enabled:
            return {"error": "Kubernetes reads are disabled"}
        self._load()
        items = client.AppsV1Api().list_namespaced_deployment(self.namespace).items
        return {
            "namespace": self.namespace,
            "deployments": [
                {
                    "name": item.metadata.name,
                    "desired": item.spec.replicas,
                    "ready": item.status.ready_replicas or 0,
                    "available": item.status.available_replicas or 0,
                    "labels": item.metadata.labels or {},
                }
                for item in items
            ],
        }

    def recent_events(self) -> dict[str, Any]:
        if not self.enabled:
            return {"error": "Kubernetes reads are disabled"}
        self._load()
        events = client.CoreV1Api().list_namespaced_event(self.namespace).items[-25:]
        return {
            "events": [
                {
                    "type": event.type,
                    "reason": event.reason,
                    "message": event.message,
                    "object": event.involved_object.name,
                }
                for event in events
            ]
        }

