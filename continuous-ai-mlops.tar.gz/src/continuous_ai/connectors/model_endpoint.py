from typing import Any

import httpx


class ModelEndpointConnector:
    def __init__(self, endpoints: dict[str, str]):
        self.endpoints = endpoints

    def list_endpoints(self) -> dict[str, str]:
        return self.endpoints

    def health(self, model_name: str) -> dict[str, Any]:
        if model_name not in self.endpoints:
            return {"error": f"No endpoint configured for {model_name}"}
        response = httpx.get(f"{self.endpoints[model_name]}/health", timeout=5)
        response.raise_for_status()
        return response.json()

    def predict(self, model_name: str, records: list[dict[str, Any]]) -> dict[str, Any]:
        if model_name not in self.endpoints:
            return {"error": f"No endpoint configured for {model_name}"}
        response = httpx.post(
            f"{self.endpoints[model_name]}/predict",
            json={"records": records},
            timeout=30,
        )
        response.raise_for_status()
        return response.json()

