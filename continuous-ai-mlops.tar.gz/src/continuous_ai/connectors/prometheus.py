from typing import Any

import httpx


class PrometheusConnector:
    def __init__(self, base_url: str | None):
        self.base_url = base_url.rstrip("/") if base_url else None

    def query(self, promql: str) -> dict[str, Any]:
        if not self.base_url:
            return {"error": "PROMETHEUS_URL is not configured"}
        response = httpx.get(
            f"{self.base_url}/api/v1/query",
            params={"query": promql},
            timeout=10,
        )
        response.raise_for_status()
        return response.json()

    def model_summary(self, model_name: str) -> dict[str, Any]:
        safe = model_name.replace('"', "")
        queries = {
            "request_rate": f'sum(rate(model_requests_total{{model_name="{safe}"}}[5m]))',
            "error_rate": (
                f'sum(rate(model_requests_total{{model_name="{safe}",status="error"}}[5m])) '
                f'/ clamp_min(sum(rate(model_requests_total{{model_name="{safe}"}}[5m])), 0.000001)'
            ),
            "latency_p95": (
                f'histogram_quantile(0.95, sum by (le) '
                f'(rate(model_request_duration_seconds_bucket{{model_name="{safe}"}}[5m])))'
            ),
        }
        return {name: self.query(query) for name, query in queries.items()}

