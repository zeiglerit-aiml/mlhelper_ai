from pathlib import Path
from typing import Any

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


class KnowledgeBase:
    """Dependency-light local RAG. Swap behind this interface for pgvector."""

    def __init__(self, directory: str):
        self.directory = Path(directory)
        self.documents: list[dict[str, str]] = []
        self.vectorizer: TfidfVectorizer | None = None
        self.matrix: Any = None
        self.refresh()

    def refresh(self) -> None:
        self.documents = [
            {"source": path.name, "text": path.read_text(encoding="utf-8")}
            for path in sorted(self.directory.glob("*.md"))
        ] if self.directory.exists() else []
        if self.documents:
            self.vectorizer = TfidfVectorizer(stop_words="english")
            self.matrix = self.vectorizer.fit_transform(d["text"] for d in self.documents)

    def search(self, query: str, limit: int = 4) -> list[dict[str, Any]]:
        if not self.documents or self.vectorizer is None:
            return []
        query_vector = self.vectorizer.transform([query])
        scores = cosine_similarity(query_vector, self.matrix)[0]
        ranked = scores.argsort()[::-1][:limit]
        return [
            {**self.documents[index], "score": float(scores[index])}
            for index in ranked
            if scores[index] > 0
        ]

