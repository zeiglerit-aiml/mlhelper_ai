"""Continuous AI MLOps assistant."""

__version__ = "0.1.0"

