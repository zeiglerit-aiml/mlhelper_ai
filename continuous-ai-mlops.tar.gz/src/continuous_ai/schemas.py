from datetime import UTC, datetime
from typing import Any, Literal
from uuid import UUID, uuid4

from pydantic import BaseModel, Field


def utc_now() -> datetime:
    return datetime.now(UTC)


class PipelineEvent(BaseModel):
    event_id: UUID = Field(default_factory=uuid4)
    event_type: Literal[
        "training.started",
        "training.completed",
        "training.failed",
        "evaluation.completed",
        "model.registered",
        "deployment.completed",
    ]
    occurred_at: datetime = Field(default_factory=utc_now)
    model_name: str
    run_id: str | None = None
    model_version: str | None = None
    dataset_version: str | None = None
    git_commit: str | None = None
    metrics: dict[str, float] = Field(default_factory=dict)
    metadata: dict[str, Any] = Field(default_factory=dict)


class PredictionEvent(BaseModel):
    prediction_id: UUID = Field(default_factory=uuid4)
    occurred_at: datetime = Field(default_factory=utc_now)
    model_name: str
    model_version: str
    prediction: str | int | float | list[float]
    probability: float | None = None
    features: dict[str, Any] = Field(default_factory=dict)
    latency_ms: float | None = None
    trace_id: str | None = None


class GroundTruthEvent(BaseModel):
    prediction_id: UUID
    actual: str | int | float
    observed_at: datetime = Field(default_factory=utc_now)


class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=20_000)


class EvaluationRequest(BaseModel):
    model_name: str
    model_version: str | None = None
    task_type: Literal["classification", "regression"] = "classification"
    minimum_samples: int = Field(default=20, ge=2)


class ExperimentRequest(BaseModel):
    model_name: str
    experiment_type: Literal[
        "threshold_search",
        "drift_analysis",
        "feature_ablation",
        "hyperparameter_search",
    ]
    parameters: dict[str, Any] = Field(default_factory=dict)
    approved: bool = False
