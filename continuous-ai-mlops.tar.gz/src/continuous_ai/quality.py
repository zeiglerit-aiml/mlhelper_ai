from typing import Any

import numpy as np
from sklearn.metrics import (
    accuracy_score,
    f1_score,
    mean_absolute_error,
    mean_squared_error,
    precision_score,
    recall_score,
)


def evaluate_records(records: list[dict[str, Any]], task_type: str) -> dict[str, Any]:
    if not records:
        return {"status": "insufficient_data", "sample_count": 0}

    y_pred = [record["prediction"] for record in records]
    y_true = [record["actual"] for record in records]

    if task_type == "regression":
        rmse = float(np.sqrt(mean_squared_error(y_true, y_pred)))
        return {
            "status": "ok",
            "sample_count": len(records),
            "mae": float(mean_absolute_error(y_true, y_pred)),
            "rmse": rmse,
        }

    return {
        "status": "ok",
        "sample_count": len(records),
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "precision_weighted": float(precision_score(y_true, y_pred, average="weighted", zero_division=0)),
        "recall_weighted": float(recall_score(y_true, y_pred, average="weighted", zero_division=0)),
        "f1_weighted": float(f1_score(y_true, y_pred, average="weighted", zero_division=0)),
    }

