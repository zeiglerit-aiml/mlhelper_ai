import json
from functools import lru_cache

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    app_name: str = "Continuous AI MLOps Assistant"
    openai_api_key: str | None = None
    openai_model: str = "gpt-5.4-mini"
    database_url: str = "sqlite:///./continuous-ai.db"
    knowledge_dir: str = "knowledge"
    mlflow_tracking_uri: str | None = None
    prometheus_url: str | None = None
    model_endpoints_json: str = "{}"
    model_namespace: str = "models"
    allow_k8s_reads: bool = True
    allow_experiment_jobs: bool = False
    allow_production_writes: bool = False
    webhook_secret: str = Field(default="change-me", min_length=8)

    @property
    def model_endpoints(self) -> dict[str, str]:
        value = json.loads(self.model_endpoints_json)
        if not isinstance(value, dict):
            raise TypeError("MODEL_ENDPOINTS_JSON must be a JSON object")
        return {str(k): str(v).rstrip("/") for k, v in value.items()}


@lru_cache
def get_settings() -> Settings:
    return Settings()
