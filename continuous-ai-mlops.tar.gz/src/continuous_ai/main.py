import hmac
from contextlib import asynccontextmanager
from typing import Annotated

from fastapi import Depends, FastAPI, Header, HTTPException
from prometheus_client import Counter, Histogram, make_asgi_app

from continuous_ai.agent import ContinuousAIAgent
from continuous_ai.config import Settings, get_settings
from continuous_ai.connectors.kubernetes import KubernetesConnector
from continuous_ai.connectors.mlflow import MLflowConnector
from continuous_ai.connectors.model_endpoint import ModelEndpointConnector
from continuous_ai.connectors.prometheus import PrometheusConnector
from continuous_ai.quality import evaluate_records
from continuous_ai.rag import KnowledgeBase
from continuous_ai.schemas import (
    ChatRequest,
    EvaluationRequest,
    ExperimentRequest,
    GroundTruthEvent,
    PipelineEvent,
    PredictionEvent,
)
from continuous_ai.store import EventStore

REQUESTS = Counter("continuous_ai_requests_total", "API requests", ["route", "status"])
LATENCY = Histogram("continuous_ai_request_duration_seconds", "Agent request duration")


class Services:
    def __init__(self, settings: Settings):
        self.settings = settings
        self.store = EventStore(settings.database_url)
        self.knowledge = KnowledgeBase(settings.knowledge_dir)
        self.mlflow = MLflowConnector(settings.mlflow_tracking_uri)
        self.prometheus = PrometheusConnector(settings.prometheus_url)
        self.models = ModelEndpointConnector(settings.model_endpoints)
        self.kubernetes = KubernetesConnector(settings.model_namespace, settings.allow_k8s_reads)
        self.agent = None
        if settings.openai_api_key:
            tools = {
                "search_knowledge": lambda query: self.knowledge.search(query),
                "evaluate_model": self.evaluate,
                "get_mlflow_model": self.mlflow.model_by_alias,
                "get_model_telemetry": self.prometheus.model_summary,
                "get_model_health": self.models.health,
                "get_kubernetes_deployments": self.kubernetes.deployments,
            }
            self.agent = ContinuousAIAgent(settings.openai_api_key, settings.openai_model, tools)

    def evaluate(
        self,
        model_name: str,
        model_version: str | None = None,
        task_type: str = "classification",
    ) -> dict:
        records = self.store.labeled_predictions(model_name, model_version)
        return evaluate_records(records, task_type)


services: Services | None = None


@asynccontextmanager
async def lifespan(_: FastAPI):
    global services
    services = Services(get_settings())
    yield


app = FastAPI(title="Continuous AI MLOps Assistant", version="0.1.0", lifespan=lifespan)
app.mount("/metrics", make_asgi_app())


def get_services() -> Services:
    if services is None:
        raise HTTPException(503, "Application is starting")
    return services


def verify_webhook(
    settings: Annotated[Settings, Depends(get_settings)],
    x_webhook_secret: Annotated[str, Header()] = "",
) -> None:
    if not hmac.compare_digest(x_webhook_secret, settings.webhook_secret):
        raise HTTPException(401, "Invalid webhook secret")


ServiceDependency = Annotated[Services, Depends(get_services)]


@app.get("/health")
def health(state: ServiceDependency) -> dict:
    return {
        "status": "healthy",
        "agent_enabled": state.agent is not None,
        "mlflow_enabled": state.mlflow.enabled,
        "prometheus_enabled": state.prometheus.base_url is not None,
        "configured_models": list(state.models.endpoints),
    }


@app.post("/v1/chat")
def chat(request: ChatRequest, state: ServiceDependency) -> dict:
    if state.agent is None:
        raise HTTPException(503, "Set OPENAI_API_KEY to enable the agent")
    with LATENCY.time():
        answer = state.agent.ask(request.message)
    REQUESTS.labels(route="chat", status="ok").inc()
    return {"answer": answer}


@app.post("/v1/events/pipeline", dependencies=[Depends(verify_webhook)])
def pipeline_event(event: PipelineEvent, state: ServiceDependency) -> dict:
    state.store.add_pipeline_event(event)
    return {"accepted": True, "event_id": str(event.event_id)}


@app.post("/v1/events/predictions", dependencies=[Depends(verify_webhook)])
def prediction_event(event: PredictionEvent, state: ServiceDependency) -> dict:
    state.store.add_prediction(event)
    return {"accepted": True, "prediction_id": str(event.prediction_id)}


@app.post("/v1/events/ground-truth", dependencies=[Depends(verify_webhook)])
def ground_truth_event(event: GroundTruthEvent, state: ServiceDependency) -> dict:
    state.store.add_ground_truth(event)
    return {"accepted": True, "prediction_id": str(event.prediction_id)}


@app.post("/v1/evaluations")
def evaluate(request: EvaluationRequest, state: ServiceDependency) -> dict:
    result = state.evaluate(request.model_name, request.model_version, request.task_type)
    if result["sample_count"] < request.minimum_samples:
        result["status"] = "insufficient_data"
        result["minimum_samples"] = request.minimum_samples
    return result


@app.post("/v1/experiments")
def create_experiment(request: ExperimentRequest, state: ServiceDependency) -> dict:
    if not state.settings.allow_experiment_jobs:
        raise HTTPException(403, "Experiment jobs are disabled by policy")
    if not request.approved:
        return {"status": "approval_required", "request": request.model_dump()}
    # Extension point: submit a signed, allow-listed Kubernetes Job template.
    return {
        "status": "accepted",
        "message": "Connect your approved experiment-runner implementation here.",
        "request": request.model_dump(),
    }
