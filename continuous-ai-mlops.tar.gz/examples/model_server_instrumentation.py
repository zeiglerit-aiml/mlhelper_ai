"""Patterns to copy into a FastAPI model-serving application."""
import os
import time
from uuid import uuid4

import httpx
from fastapi import FastAPI
from prometheus_client import Counter, Histogram, make_asgi_app
from pydantic import BaseModel

app = FastAPI()
app.mount("/metrics", make_asgi_app())

MODEL_NAME = os.getenv("MODEL_NAME", "fraud-detector")
MODEL_VERSION = os.getenv("MODEL_VERSION", "1")
ASSISTANT_URL = os.environ["CONTINUOUS_AI_URL"]
WEBHOOK_SECRET = os.environ["CONTINUOUS_AI_WEBHOOK_SECRET"]

REQUESTS = Counter("model_requests_total", "Model requests", ["model_name", "version", "status"])
LATENCY = Histogram(
    "model_request_duration_seconds", "Inference latency", ["model_name", "version"]
)


class InferenceRequest(BaseModel):
    features: dict[str, float]


def model_predict(features: dict[str, float]) -> tuple[int, float]:
    """Replace with your loaded MLflow, sklearn, PyTorch, or TensorFlow model."""
    probability = min(max(sum(features.values()) / max(len(features), 1), 0.0), 1.0)
    return int(probability >= 0.5), probability


@app.get("/health")
def health() -> dict:
    return {"status": "healthy", "model": MODEL_NAME, "version": MODEL_VERSION}


@app.post("/predict")
def predict(request: InferenceRequest) -> dict:
    prediction_id = uuid4()
    started = time.perf_counter()
    try:
        prediction, probability = model_predict(request.features)
        latency_ms = (time.perf_counter() - started) * 1000
        REQUESTS.labels(MODEL_NAME, MODEL_VERSION, "ok").inc()
        LATENCY.labels(MODEL_NAME, MODEL_VERSION).observe(latency_ms / 1000)

        # For high throughput, publish this event asynchronously to Kafka/Pub/Sub/Kinesis.
        httpx.post(
            f"{ASSISTANT_URL}/v1/events/predictions",
            headers={"X-Webhook-Secret": WEBHOOK_SECRET},
            json={
                "prediction_id": str(prediction_id),
                "model_name": MODEL_NAME,
                "model_version": MODEL_VERSION,
                "prediction": prediction,
                "probability": probability,
                "features": request.features,
                "latency_ms": latency_ms,
            },
            timeout=2,
        ).raise_for_status()
        return {
            "prediction_id": prediction_id,
            "prediction": prediction,
            "probability": probability,
        }
    except Exception:
        REQUESTS.labels(MODEL_NAME, MODEL_VERSION, "error").inc()
        raise

