"""Send delayed outcomes after joining them to prediction_id in your data platform."""
import os
import sys

import httpx

response = httpx.post(
    f"{os.environ['CONTINUOUS_AI_URL']}/v1/events/ground-truth",
    headers={"X-Webhook-Secret": os.environ["CONTINUOUS_AI_WEBHOOK_SECRET"]},
    json={"prediction_id": sys.argv[1], "actual": int(sys.argv[2])},
    timeout=10,
)
response.raise_for_status()
print(response.json())

