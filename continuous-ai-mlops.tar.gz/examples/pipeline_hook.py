"""Call this from Airflow, Kubeflow, Vertex Pipelines, Argo, or plain Python."""
import os

import httpx


def notify_training_complete(
    model_name: str,
    run_id: str,
    model_version: str,
    dataset_version: str,
    metrics: dict[str, float],
) -> None:
    response = httpx.post(
        f"{os.environ['CONTINUOUS_AI_URL']}/v1/events/pipeline",
        headers={"X-Webhook-Secret": os.environ["CONTINUOUS_AI_WEBHOOK_SECRET"]},
        json={
            "event_type": "training.completed",
            "model_name": model_name,
            "run_id": run_id,
            "model_version": model_version,
            "dataset_version": dataset_version,
            "git_commit": os.getenv("GIT_COMMIT"),
            "metrics": metrics,
        },
        timeout=10,
    )
    response.raise_for_status()


if __name__ == "__main__":
    notify_training_complete(
        model_name="fraud-detector",
        run_id="replace-with-mlflow-run-id",
        model_version="17",
        dataset_version="transactions-2026-08-25",
        metrics={"recall": 0.91, "precision": 0.87},
    )

