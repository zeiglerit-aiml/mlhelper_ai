variable "project_id" { type = string }
variable "region" { type = string }
variable "name" {
  type    = string
  default = "continuous-ai"
}
variable "node_count" {
  type    = number
  default = 2
}
variable "machine_type" {
  type    = string
  default = "e2-standard-4"
}
