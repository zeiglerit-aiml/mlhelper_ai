variable "name" {
  type    = string
  default = "continuous-ai"
}
variable "location" { type = string }
variable "node_count" {
  type    = number
  default = 2
}
variable "vm_size" {
  type    = string
  default = "Standard_D4s_v5"
}
