output "namespace" { value = kubernetes_namespace_v1.app.metadata[0].name }
output "service_name" { value = helm_release.app.name }
output "in_cluster_url" {
  value = "http://${helm_release.app.name}.${kubernetes_namespace_v1.app.metadata[0].name}.svc.cluster.local:8080"
}

