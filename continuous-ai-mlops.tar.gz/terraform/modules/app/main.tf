resource "kubernetes_namespace_v1" "app" {
  metadata { name = var.namespace }
}

resource "kubernetes_namespace_v1" "models" {
  count = var.create_model_namespace && var.model_namespace != var.namespace ? 1 : 0
  metadata { name = var.model_namespace }
}

resource "kubernetes_secret_v1" "app" {
  metadata {
    name      = "continuous-ai-secrets"
    namespace = kubernetes_namespace_v1.app.metadata[0].name
  }
  data = {
    OPENAI_API_KEY = var.openai_api_key
    WEBHOOK_SECRET = var.webhook_secret
  }
  type = "Opaque"
}

resource "helm_release" "app" {
  name       = "continuous-ai"
  namespace  = kubernetes_namespace_v1.app.metadata[0].name
  chart      = var.chart_path
  wait       = true
  timeout    = 600

  values = [yamlencode({
    image = {
      repository = var.image_repository
      tag        = var.image_tag
    }
    config = {
      mlflowTrackingUri  = var.mlflow_tracking_uri
      prometheusUrl      = var.prometheus_url
      modelNamespace     = var.model_namespace
      modelEndpointsJson = jsonencode(var.model_endpoints)
      allowExperimentJobs = var.allow_experiment_jobs
    }
    persistence = { storageClass = var.storage_class }
    rbac = { allowExperimentJobs = var.allow_experiment_jobs }
    serviceMonitor = { enabled = var.service_monitor_enabled }
  })]

  depends_on = [kubernetes_secret_v1.app, kubernetes_namespace_v1.models]
}
