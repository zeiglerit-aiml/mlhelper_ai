variable "name" {
  type    = string
  default = "continuous-ai"
}
variable "region" { type = string }
variable "kubernetes_version" {
  type    = string
  default = "1.33"
}
