data "aws_availability_zones" "available" { state = "available" }

module "vpc" {
  source  = "terraform-aws-modules/vpc/aws"
  version = "~> 6.0"
  name    = "${var.name}-vpc"
  cidr    = "10.30.0.0/16"
  azs     = slice(data.aws_availability_zones.available.names, 0, 3)
  private_subnets = ["10.30.0.0/20", "10.30.16.0/20", "10.30.32.0/20"]
  public_subnets  = ["10.30.128.0/24", "10.30.129.0/24", "10.30.130.0/24"]
  enable_nat_gateway = true
  single_nat_gateway = true
  public_subnet_tags = { "kubernetes.io/role/elb" = "1" }
  private_subnet_tags = { "kubernetes.io/role/internal-elb" = "1" }
}

module "eks" {
  source  = "terraform-aws-modules/eks/aws"
  version = "~> 21.0"
  name               = var.name
  kubernetes_version = var.kubernetes_version
  endpoint_public_access = true
  enable_cluster_creator_admin_permissions = true
  vpc_id     = module.vpc.vpc_id
  subnet_ids = module.vpc.private_subnets
  eks_managed_node_groups = {
    general = {
      instance_types = ["m6i.xlarge"]
      min_size = 2
      max_size = 5
      desired_size = 2
    }
  }
}

