output "name" { value = module.eks.cluster_name }
output "endpoint" { value = module.eks.cluster_endpoint }
output "cluster_ca_certificate" {
  value     = module.eks.cluster_certificate_authority_data
  sensitive = true
}
