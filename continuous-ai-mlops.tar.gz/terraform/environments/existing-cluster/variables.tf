variable "kubeconfig_path" {
  type    = string
  default = "~/.kube/config"
}
variable "kubeconfig_context" {
  type    = string
  default = null
}
variable "image_repository" { type = string }
variable "image_tag" {
  type    = string
  default = "0.1.0"
}
variable "openai_api_key" {
  type      = string
  sensitive = true
}
variable "webhook_secret" {
  type      = string
  sensitive = true
}
variable "mlflow_tracking_uri" { type = string }
variable "prometheus_url" { type = string }
variable "model_namespace" {
  type    = string
  default = "models"
}
variable "create_model_namespace" {
  type    = bool
  default = false
}
variable "model_endpoints" {
  type    = map(string)
  default = {}
}
variable "service_monitor_enabled" {
  type    = bool
  default = false
}
