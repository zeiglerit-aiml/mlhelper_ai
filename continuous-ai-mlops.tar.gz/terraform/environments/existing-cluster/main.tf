module "app" {
  source                  = "../../modules/app"
  chart_path              = "../../../helm/continuous-ai"
  image_repository        = var.image_repository
  image_tag               = var.image_tag
  openai_api_key          = var.openai_api_key
  webhook_secret          = var.webhook_secret
  mlflow_tracking_uri     = var.mlflow_tracking_uri
  prometheus_url          = var.prometheus_url
  model_namespace         = var.model_namespace
  create_model_namespace  = var.create_model_namespace
  model_endpoints         = var.model_endpoints
  service_monitor_enabled = var.service_monitor_enabled
}

output "continuous_ai_url" { value = module.app.in_cluster_url }
