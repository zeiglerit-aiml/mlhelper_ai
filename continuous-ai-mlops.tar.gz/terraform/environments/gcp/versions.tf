terraform {
  required_version = ">= 1.7"
  required_providers {
    google     = { source = "hashicorp/google", version = "~> 7.0" }
    kubernetes = { source = "hashicorp/kubernetes", version = "~> 2.36" }
    helm       = { source = "hashicorp/helm", version = "~> 3.0" }
  }
}

