provider "azurerm" { features {} }

module "cluster" {
  source   = "../../modules/aks"
  name     = var.cluster_name
  location = var.location
}

provider "kubernetes" {
  host                   = module.cluster.host
  client_certificate     = base64decode(module.cluster.client_certificate)
  client_key             = base64decode(module.cluster.client_key)
  cluster_ca_certificate = base64decode(module.cluster.cluster_ca_certificate)
}

provider "helm" {
  kubernetes = {
    host                   = module.cluster.host
    client_certificate     = base64decode(module.cluster.client_certificate)
    client_key             = base64decode(module.cluster.client_key)
    cluster_ca_certificate = base64decode(module.cluster.cluster_ca_certificate)
  }
}

module "app" {
  source              = "../../modules/app"
  chart_path          = "../../../helm/continuous-ai"
  image_repository    = var.image_repository
  image_tag           = var.image_tag
  openai_api_key      = var.openai_api_key
  webhook_secret      = var.webhook_secret
  mlflow_tracking_uri = var.mlflow_tracking_uri
  prometheus_url      = var.prometheus_url
  model_namespace     = var.model_namespace
  model_endpoints     = var.model_endpoints
  depends_on          = [module.cluster]
}

output "cluster_name" { value = module.cluster.name }
output "continuous_ai_url" { value = module.app.in_cluster_url }

