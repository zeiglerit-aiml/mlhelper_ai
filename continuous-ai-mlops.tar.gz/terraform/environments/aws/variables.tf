variable "region" {
  type    = string
  default = "us-east-1"
}
variable "cluster_name" {
  type    = string
  default = "continuous-ai"
}
variable "image_repository" { type = string }
variable "image_tag" {
  type    = string
  default = "0.1.0"
}
variable "openai_api_key" {
  type      = string
  sensitive = true
}
variable "webhook_secret" {
  type      = string
  sensitive = true
}
variable "mlflow_tracking_uri" { type = string }
variable "prometheus_url" { type = string }
variable "model_namespace" {
  type    = string
  default = "models"
}
variable "model_endpoints" {
  type    = map(string)
  default = {}
}
