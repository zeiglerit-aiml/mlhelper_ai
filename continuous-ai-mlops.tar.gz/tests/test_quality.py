from continuous_ai.quality import evaluate_records


def test_classification_metrics():
    records = [
        {"prediction": 1, "actual": 1},
        {"prediction": 0, "actual": 0},
        {"prediction": 1, "actual": 0},
        {"prediction": 1, "actual": 1},
    ]
    result = evaluate_records(records, "classification")
    assert result["sample_count"] == 4
    assert result["accuracy"] == 0.75


def test_regression_metrics():
    records = [
        {"prediction": 2.0, "actual": 1.0},
        {"prediction": 3.0, "actual": 3.0},
    ]
    result = evaluate_records(records, "regression")
    assert result["mae"] == 0.5

