from uuid import uuid4

from continuous_ai.schemas import GroundTruthEvent, PredictionEvent
from continuous_ai.store import EventStore


def test_join_prediction_to_ground_truth(tmp_path):
    store = EventStore(f"sqlite:///{tmp_path}/events.db")
    prediction_id = uuid4()
    store.add_prediction(
        PredictionEvent(
            prediction_id=prediction_id,
            model_name="test-model",
            model_version="1",
            prediction=1,
        )
    )
    store.add_ground_truth(GroundTruthEvent(prediction_id=prediction_id, actual=1))
    records = store.labeled_predictions("test-model")
    assert records[0]["prediction"] == 1
    assert records[0]["actual"] == 1

