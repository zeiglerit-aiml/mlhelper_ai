# Continuous AI MLOps Assistant

Continuous AI MLOps Assistant is a Kubernetes-native agentic RAG platform for improving the way ML
models are evaluated and operated. It connects training pipelines, MLflow, model-serving endpoints,
ground-truth outcomes, Prometheus telemetry, Kubernetes health, model cards, policies, and runbooks in
one evidence-driven investigation loop.

The assistant can calculate real model quality, inspect champion and challenger versions, correlate
production symptoms with training lineage, diagnose likely causes of degradation, and propose targeted
experiments. Its default deployment is read-only and uses deterministic quality and policy gates;
optional experiment execution is explicitly controlled. The repository includes Python, FastAPI,
Docker, Helm, and Terraform deployment paths for existing Kubernetes, GKE, EKS, and AKS.

