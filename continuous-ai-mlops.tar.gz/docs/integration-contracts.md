# Integration contracts

## Connection modes

The recommended deployment uses all three modes together:

| Mode | Direction | Purpose |
|---|---|---|
| Pipeline events | pipeline to assistant | Notify the assistant about runs, data, evaluation, registration, and deployment |
| Platform reads | assistant to MLflow/Prometheus/Kubernetes | Investigate authoritative system state |
| Serving/outcome events | endpoints and data pipeline to assistant | Join predictions to delayed ground truth and calculate quality |

Pipeline-only integration lacks production outcomes. Serving-only integration lacks training lineage.
Using both lets the assistant connect a production symptom to its model version, run, dataset, code,
deployment, and eventual outcome.

## Pipeline event contract

Required fields are `event_type` and `model_name`. Always include the MLflow `run_id`, registered
`model_version`, immutable `dataset_version`, and `git_commit` when known. Send a stable event ID when
the caller may retry; ingestion is idempotent by ID.

Protect the endpoint with the webhook secret, TLS, and network policy or an internal gateway. Replace
the shared secret with workload identity and signed service tokens for a mature deployment.

## Prediction contract

Every prediction must have a globally unique `prediction_id`, model name, immutable model version,
timestamp, prediction value, and trace ID. Probability and features are optional. Before sending
features, establish an allowlist to prevent personal, confidential, or regulated fields from being
stored unintentionally.

At high volume, change the transport from direct HTTP to a durable stream. Preserve the JSON schema so
the downstream consumer remains compatible.

## Ground-truth contract

Ground truth uses the original `prediction_id`. Outcomes may arrive minutes or months later. Evaluate
only complete, representative windows and enforce minimum sample sizes. Repeated outcomes for a
prediction replace the prior value in this MVP; production systems should retain revision history.

## Model endpoint contract

The default adapter expects `/health` and `/predict`. If an endpoint uses KServe V2, MLflow serving,
SageMaker, Vertex AI, Azure ML, Triton, or custom authentication, add a connector implementing the same
`health` and `predict` methods instead of changing the agent.

## Prometheus contract

Endpoint instrumentation must preserve the `model_name`, `version`, and `status` labels. Avoid labels
with unbounded values such as prediction IDs or user IDs. Use traces or logs for per-request lookup.

## RAG contract

Place model cards, policies, and runbooks in `knowledge/*.md` for the MVP. Documents should state
owners, model scope, primary and safety metrics, evaluation windows, deployment gates, and rollback
conditions. The retriever returns source names and text; a future vector-store adapter should preserve
that response shape and add immutable document versions.

