# Security and permissions

## Default trust model

The LLM proposes and explains. Deterministic connectors gather evidence. Deterministic code calculates
metrics. Policy gates authorize actions. The model is never treated as the source of measured facts.

## Kubernetes RBAC

The default cross-namespace Role permits only:

```text
get/list/watch: pods, pods/log, services, events, deployments, replicasets
```

It deliberately excludes Secrets, ConfigMaps, exec, port-forward, admission resources, Roles,
RoleBindings, and production writes. Optional Job permission is namespaced and must be paired with an
allow-listed job builder, image signature verification, quotas, timeout, and restricted service
account for the created Job.

## Credentials

- Supply the OpenAI API key and webhook secret through Terraform sensitive variables.
- Use a remote Terraform backend with encryption and tightly restricted state access; sensitive values
  are still present in state.
- Prefer cloud workload identity for registry, storage, and managed monitoring access.
- Do not send secrets, raw tokens, or unrestricted customer features to the model.

## Network access

The application needs HTTPS egress to the configured model API and internal access to MLflow,
Prometheus, Kubernetes API, and registered model endpoints. Enable the sample ingress NetworkPolicy
only after adapting selectors and egress rules to your CNI and namespaces. A generic deny-all egress
policy would break DNS and platform connections.

## Action maturity

1. Read-only investigation.
2. Evaluation jobs on immutable snapshots.
3. Approved experiment jobs in a restricted namespace.
4. GitOps pull requests that alter canary configuration.
5. Automatic rollback to a known champion under deterministic emergency gates.
6. Promotion only after enough labeled outcomes and explicit policy authorization.

Record every tool call, input reference, output, policy decision, approval, Git commit, model version,
and deployment result in an immutable audit sink before enabling write capabilities.

